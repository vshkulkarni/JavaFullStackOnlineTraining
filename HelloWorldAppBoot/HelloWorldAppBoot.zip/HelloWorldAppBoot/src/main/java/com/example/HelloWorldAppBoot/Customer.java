package com.example.HelloWorldAppBoot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Customer {
	private int custid;
	private String custname;
	private String coursename;
	@Autowired
	private Technology techDetails;

	public Technology getTechDetails() {
		return techDetails;
	}

	public void setTechDetails(Technology techDetails) {
		this.techDetails = techDetails;
	}

	public int getCustid() {
		return custid;
	}

	public void setCustid(int custid) {
		this.custid = custid;
	}

	public String getCustname() {
		return custname;
	}

	public void setCustname(String custname) {
		this.custname = custname;
	}

	public String getCoursename() {
		return coursename;
	}

	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	
	public void display()
	{
		System.out.println("Customer Object retun successfully");
		techDetails.tech();
	}

}
