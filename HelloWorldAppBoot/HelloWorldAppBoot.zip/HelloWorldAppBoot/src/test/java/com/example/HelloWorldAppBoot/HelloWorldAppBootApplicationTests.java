package com.example.HelloWorldAppBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloWorldAppBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
